import logo from './logo.svg';
import './App.css';
import GetStartedForm from './component/get-started-form';


function App() {
  return (
    <div className="App">
      <GetStartedForm/>
    </div>
  );
}

export default App;
